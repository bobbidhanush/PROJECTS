package com.company;
import java.math.BigInteger;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

public class ParallelFibonacci {

    private static final ForkJoinPool pool = new ForkJoinPool();

    public static void main(String[] args) {
        int n = 100000; // Set the desired Fibonacci number here

        long startTime = System.nanoTime();
        BigInteger result = fastFibonacciMatrixParallel(n);
        long endTime = System.nanoTime();

        System.out.println("Fibonacci(" + n + ") = " + result);
        System.out.println("Execution Time: " + (endTime - startTime) + " nanoseconds");
    }

    private static BigInteger fastFibonacciMatrixParallel(int n) {
        BigInteger[] matrix = {BigInteger.ONE, BigInteger.ONE, BigInteger.ONE, BigInteger.ZERO};
        return pool.invoke(new MatrixPowTask(matrix, n, 4))[1];
    }

    private static class MatrixPowTask extends RecursiveTask<BigInteger[]> {
        private final BigInteger[] matrix;
        private final int n;
        private final int threads;

        MatrixPowTask(BigInteger[] matrix, int n, int threads) {
            this.matrix = matrix;
            this.n = n;
            this.threads = threads;
        }

        @Override
        protected BigInteger[] compute() {
            if (n < 0)
                throw new IllegalArgumentException();

            if (n == 0) {
                return new BigInteger[]{BigInteger.ONE, BigInteger.ZERO, BigInteger.ZERO, BigInteger.ONE};
            }

            if (n == 1) {
                return matrix;
            }

            if (n <= threads) {
                return matrixPow(matrix, n);
            }

            MatrixPowTask[] subtasks = new MatrixPowTask[threads];
            for (int i = 0; i < threads; i++) {
                int subProblemSize = n / threads;
                subtasks[i] = new MatrixPowTask(matrix, subProblemSize, threads);
                subtasks[i].fork();
            }

            BigInteger[] result = new BigInteger[]{BigInteger.ONE, BigInteger.ZERO, BigInteger.ZERO, BigInteger.ONE};
            for (int i = 0; i < threads; i++) {
                BigInteger[] subResult = subtasks[i].join();
                result = matrixMultiply(result, subResult);
            }

            return result;
        }
    }

    private static BigInteger[] matrixMultiply(BigInteger[] x, BigInteger[] y) {
        return new BigInteger[]{
                x[0].multiply(y[0]).add(x[1].multiply(y[2])),
                x[0].multiply(y[1]).add(x[1].multiply(y[3])),
                x[2].multiply(y[0]).add(x[3].multiply(y[2])),
                x[2].multiply(y[1]).add(x[3].multiply(y[3]))
        };
    }

    private static BigInteger[] matrixPow(BigInteger[] matrix, int n) {
        if (n == 0) {
            return new BigInteger[]{BigInteger.ONE, BigInteger.ZERO, BigInteger.ZERO, BigInteger.ONE};
        }

        if (n % 2 == 0) {
            BigInteger[] halfPow = matrixPow(matrix, n / 2);
            return matrixMultiply(halfPow, halfPow);
        } else {
            return matrixMultiply(matrix, matrixPow(matrix, n - 1));
        }
    }
}
