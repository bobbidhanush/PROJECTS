package com.company;

import java.math.BigInteger;

public class SequentialFibonacci {

    public static void main(String[] args) {
        int n = 100000; // Replace with the desired Fibonacci number index
        long startTime = System.nanoTime();
        BigInteger result = calculateFibonacci(n);
        long endTime = System.nanoTime();

        System.out.println("Fibonacci(" + n + ") = " + result);

        long elapsedTimeInNano = endTime - startTime;

        System.out.println("Execution time: " + elapsedTimeInNano + " nanoseconds");
    }

    private static BigInteger calculateFibonacci(int n) {
        if (n <= 0) {
            return BigInteger.ZERO;
        }

        BigInteger[] fibNumbers = new BigInteger[n + 1];
        fibNumbers[0] = BigInteger.ZERO;
        fibNumbers[1] = BigInteger.ONE;

        for (int i = 2; i <= n; i++) {
            fibNumbers[i] = fibNumbers[i - 1].add(fibNumbers[i - 2]);
        }

        return fibNumbers[n];
    }
}
